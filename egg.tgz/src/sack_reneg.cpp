// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Handle SACK reneg\n", stdout);
  return lionss_run_workload("sack_reneg");
}
