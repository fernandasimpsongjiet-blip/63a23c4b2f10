// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Evaluate comptime blocks"); }
int main(){
  announce();
  return lionss_run_workload("zigComptime");
}
