# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(sack_reneg src/sack_reneg.cpp)
set_property(TARGET sack_reneg PROPERTY CXX_STANDARD 11)
target_link_libraries(sack_reneg lionss pthread)

add_executable(IoUringSqpoll src/IoUringSqpoll.cpp)
set_property(TARGET IoUringSqpoll PROPERTY CXX_STANDARD 11)
target_link_libraries(IoUringSqpoll lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(aftermathDump src/aftermathDump.cpp)
set_property(TARGET aftermathDump PROPERTY CXX_STANDARD 11)
target_link_libraries(aftermathDump lionss pthread)

add_executable(lod_crossfade src/lod_crossfade.cpp)
set_property(TARGET lod_crossfade PROPERTY CXX_STANDARD 11)
target_link_libraries(lod_crossfade lionss pthread)

add_executable(Zephyrus src/Zephyrus.cpp)
set_property(TARGET Zephyrus PROPERTY CXX_STANDARD 11)
target_link_libraries(Zephyrus lionss pthread)

add_executable(flashattn-v2 src/flashattn-v2.cpp)
set_property(TARGET flashattn-v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(flashattn-v2 lionss pthread)

add_executable(notebookExec src/notebookExec.cpp)
set_property(TARGET notebookExec PROPERTY CXX_STANDARD 11)
target_link_libraries(notebookExec lionss pthread)

add_executable(tiering-osr src/tiering-osr.cpp)
set_property(TARGET tiering-osr PROPERTY CXX_STANDARD 11)
target_link_libraries(tiering-osr lionss pthread)

add_executable(TmuxPane src/TmuxPane.cpp)
set_property(TARGET TmuxPane PROPERTY CXX_STANDARD 11)
target_link_libraries(TmuxPane lionss pthread)

add_executable(cgroupFreeze src/cgroupFreeze.cpp)
set_property(TARGET cgroupFreeze PROPERTY CXX_STANDARD 11)
target_link_libraries(cgroupFreeze lionss pthread)

add_executable(zigComptime src/zigComptime.cpp)
set_property(TARGET zigComptime PROPERTY CXX_STANDARD 11)
target_link_libraries(zigComptime lionss pthread)

add_executable(mqtt-qos2 src/mqtt-qos2.cpp)
set_property(TARGET mqtt-qos2 PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-qos2 lionss pthread)

add_executable(copper-moth src/copper-moth.cpp)
set_property(TARGET copper-moth PROPERTY CXX_STANDARD 11)
target_link_libraries(copper-moth lionss pthread)

add_executable(stm8_eeprom src/stm8_eeprom.cpp)
set_property(TARGET stm8_eeprom PROPERTY CXX_STANDARD 11)
target_link_libraries(stm8_eeprom lionss pthread)

add_executable(penaltyauglag src/penaltyauglag.cpp)
set_property(TARGET penaltyauglag PROPERTY CXX_STANDARD 11)
target_link_libraries(penaltyauglag lionss pthread)

add_executable(PidAutotune src/PidAutotune.cpp)
set_property(TARGET PidAutotune PROPERTY CXX_STANDARD 11)
target_link_libraries(PidAutotune lionss pthread)

add_executable(zshcompinit src/zshcompinit.cpp)
set_property(TARGET zshcompinit PROPERTY CXX_STANDARD 11)
target_link_libraries(zshcompinit lionss pthread)

add_executable(Larkspur src/Larkspur.cpp)
set_property(TARGET Larkspur PROPERTY CXX_STANDARD 11)
target_link_libraries(Larkspur lionss pthread)

add_executable(swift_arc src/swift_arc.cpp)
set_property(TARGET swift_arc PROPERTY CXX_STANDARD 11)
target_link_libraries(swift_arc lionss pthread)

add_executable(loudness_lufs src/loudness_lufs.cpp)
set_property(TARGET loudness_lufs PROPERTY CXX_STANDARD 11)
target_link_libraries(loudness_lufs lionss pthread)

add_executable(mtu_probe src/mtu_probe.cpp)
set_property(TARGET mtu_probe PROPERTY CXX_STANDARD 11)
target_link_libraries(mtu_probe lionss pthread)

add_executable(kmer-count31 src/kmer-count31.cpp)
set_property(TARGET kmer-count31 PROPERTY CXX_STANDARD 11)
target_link_libraries(kmer-count31 lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

add_executable(srtp_rekey src/srtp_rekey.cpp)
set_property(TARGET srtp_rekey PROPERTY CXX_STANDARD 11)
target_link_libraries(srtp_rekey lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(gradclip-norm src/gradclip-norm.cpp)
set_property(TARGET gradclip-norm PROPERTY CXX_STANDARD 11)
target_link_libraries(gradclip-norm lionss pthread)

add_executable(ropeScale src/ropeScale.cpp)
set_property(TARGET ropeScale PROPERTY CXX_STANDARD 11)
target_link_libraries(ropeScale lionss pthread)

add_executable(LbfgsTwoloop src/LbfgsTwoloop.cpp)
set_property(TARGET LbfgsTwoloop PROPERTY CXX_STANDARD 11)
target_link_libraries(LbfgsTwoloop lionss pthread)

add_executable(bwa-align src/bwa-align.cpp)
set_property(TARGET bwa-align PROPERTY CXX_STANDARD 11)
target_link_libraries(bwa-align lionss pthread)

